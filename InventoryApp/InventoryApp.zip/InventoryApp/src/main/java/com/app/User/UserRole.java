package com.app.User;

public enum UserRole {
CUSTOMER,ADMIN
}
